
  # تصميم برنامج حسب المتطلبات

  This is a code bundle for تصميم برنامج حسب المتطلبات. The original project is available at https://www.figma.com/design/onqCFWF6DD0jHxdD0vWv4c/%D8%AA%D8%B5%D9%85%D9%8A%D9%85-%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D8%AC-%D8%AD%D8%B3%D8%A8-%D8%A7%D9%84%D9%85%D8%AA%D8%B7%D9%84%D8%A8%D8%A7%D8%AA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  