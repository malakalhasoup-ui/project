import { useState, useEffect, useRef, useCallback } from "react";
import {
  Home, Users, Search, FileText, MapPin, Archive, Settings, Bell,
  UserPlus, Edit, ChevronRight, ChevronLeft, Save, Plus, Trash2,
  Printer, BarChart2, LogOut, Camera, X, Upload, CheckCircle,
  Shield, Database, Lock, RefreshCw, AlertTriangle
} from "lucide-react";

// ─── Theme ───────────────────────────────────────────────────────────────────
const C = {
  headerBg:    "#3d2b1f",
  headerText:  "#f0e8d0",
  navBg:       "#5a3e28",
  navActive:   "#c8a84a",
  sidebarBg:   "#2d4a1e",
  sidebarText: "#d0e8c0",
  sidebarHover:"#3d6428",
  contentBg:   "#e8e8dc",
  panelBg:     "#f0f0e8",
  tabActive:   "#4a7c2f",
  tabText:     "#1a1a1a",
  tableHead:   "#4a7c2f",
  tableRow:    "#f8f8f0",
  tableAlt:    "#eaeae0",
  border:      "#b0a888",
  inputBg:     "#ffffff",
  btnGreen:    "#4a7c2f",
  btnRed:      "#8b2515",
  btnGray:     "#6b6b5a",
  btnBlue:     "#1e5a8a",
  accent:      "#c8a84a",
  listSelect:  "#d0e8f8",
};

// ─── Toast system ─────────────────────────────────────────────────────────────
type ToastItem = { id: number; msg: string; type: "ok" | "err" | "info" };
let _tid = 0;

function useToast() {
  const [list, setList] = useState<ToastItem[]>([]);
  const add = useCallback((msg: string, type: ToastItem["type"] = "ok") => {
    const id = ++_tid;
    setList(p => [...p, { id, msg, type }]);
    setTimeout(() => setList(p => p.filter(t => t.id !== id)), 3000);
  }, []);
  const remove = useCallback((id: number) => setList(p => p.filter(t => t.id !== id)), []);
  return { list, add, remove };
}

function Toasts({ list, remove }: { list: ToastItem[]; remove: (id: number) => void }) {
  const bg = { ok: C.btnGreen, err: C.btnRed, info: C.btnBlue };
  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 flex flex-col gap-2 z-50 pointer-events-none" style={{ minWidth: 260 }}>
      {list.map(t => (
        <div key={t.id} className="flex items-center gap-2 px-4 py-2 rounded shadow-xl text-xs font-bold text-white pointer-events-auto"
          style={{ backgroundColor: bg[t.type] }}>
          {t.type === "ok"   && <CheckCircle size={14} />}
          {t.type === "err"  && <AlertTriangle size={14} />}
          {t.type === "info" && <Bell size={14} />}
          <span className="flex-1">{t.msg}</span>
          <button onClick={() => remove(t.id)} className="opacity-70 hover:opacity-100"><X size={12} /></button>
        </div>
      ))}
    </div>
  );
}

// ─── Confirm dialog ───────────────────────────────────────────────────────────
function Confirm({ msg, onYes, onNo }: { msg: string; onYes: () => void; onNo: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.5)" }}>
      <div className="rounded-lg shadow-2xl p-5 flex flex-col gap-4" style={{ background: C.panelBg, minWidth: 300 }} dir="rtl">
        <p className="text-sm font-semibold">{msg}</p>
        <div className="flex gap-2 justify-start">
          <button onClick={onYes} className="px-5 py-1.5 rounded text-xs font-bold text-white" style={{ background: C.btnRed }}>تأكيد</button>
          <button onClick={onNo}  className="px-5 py-1.5 rounded text-xs font-bold text-white" style={{ background: C.btnGray }}>إلغاء</button>
        </div>
      </div>
    </div>
  );
}

// ─── Add-row dialog ───────────────────────────────────────────────────────────
function AddRowDialog({ cols, onSave, onCancel }: {
  cols: string[]; onSave: (vals: string[]) => void; onCancel: () => void;
}) {
  const [vals, setVals] = useState(cols.map(() => ""));
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.5)" }}>
      <div className="rounded-lg shadow-2xl p-5 flex flex-col gap-3" style={{ background: C.panelBg, minWidth: 320 }} dir="rtl">
        <h3 className="text-sm font-bold" style={{ color: C.tableHead }}>إضافة سجل جديد</h3>
        {cols.map((c, i) => (
          <div key={c} className="flex items-center gap-2">
            <label className="text-xs font-semibold shrink-0" style={{ minWidth: 100 }}>{c}</label>
            <input autoFocus={i === 1}
              className="flex-1 border rounded px-2 py-1 text-xs"
              style={{ borderColor: C.border, background: C.inputBg }}
              value={vals[i]}
              onChange={e => setVals(p => { const n = [...p]; n[i] = e.target.value; return n; })} />
          </div>
        ))}
        <div className="flex gap-2 justify-start mt-1">
          <button onClick={() => onSave(vals)} className="px-5 py-1.5 rounded text-xs font-bold text-white" style={{ background: C.btnGreen }}>حفظ</button>
          <button onClick={onCancel}           className="px-5 py-1.5 rounded text-xs font-bold text-white" style={{ background: C.btnGray }}>إلغاء</button>
        </div>
      </div>
    </div>
  );
}

// ─── Shared UI pieces ─────────────────────────────────────────────────────────
function Field({ label, value, onChange, type = "text", readOnly = false }: {
  label: string; value: string; onChange?: (v: string) => void; type?: string; readOnly?: boolean;
}) {
  return (
    <div className="flex items-center gap-2 mb-2 w-full" dir="rtl">
      <label className="text-xs font-semibold shrink-0" style={{ minWidth: 116, color: "#2d2d20" }}>{label}</label>
      <input type={type} value={value} readOnly={readOnly}
        onChange={e => onChange?.(e.target.value)}
        className="flex-1 border rounded px-2 py-0.5 text-xs outline-none focus:ring-1"
        style={{ borderColor: C.border, background: readOnly ? "#f0f0e8" : C.inputBg, color: "#1a1a1a", minWidth: 0 }} />
    </div>
  );
}

function Sel({ label, value, onChange, options }: {
  label: string; value: string; onChange: (v: string) => void; options: string[];
}) {
  return (
    <div className="flex items-center gap-2 mb-2 w-full" dir="rtl">
      <label className="text-xs font-semibold shrink-0" style={{ minWidth: 116, color: "#2d2d20" }}>{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)}
        className="flex-1 border rounded px-2 py-0.5 text-xs outline-none"
        style={{ borderColor: C.border, background: C.inputBg, color: "#1a1a1a", minWidth: 0 }}>
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}

function Btn({ label, icon: Icon, color = C.btnGreen, onClick, small, disabled }: {
  label: string; icon?: any; color?: string; onClick?: () => void; small?: boolean; disabled?: boolean;
}) {
  return (
    <button onClick={onClick} disabled={disabled}
      className="flex items-center gap-1 rounded font-bold text-white px-2 py-1 text-xs transition-opacity hover:opacity-80 active:opacity-60 disabled:opacity-40"
      style={{ background: color }}>
      {Icon && <Icon size={small ? 12 : 13} />}
      {label}
    </button>
  );
}

// ─── Editable data table ──────────────────────────────────────────────────────
function ETable({ cols, rows, setRows, showPhoto, toast }: {
  cols: string[]; rows: string[][];
  setRows: React.Dispatch<React.SetStateAction<string[][]>>;
  showPhoto?: boolean;
  toast: (msg: string, t?: ToastItem["type"]) => void;
}) {
  const [adding, setAdding] = useState(false);
  const photoRef = useRef<HTMLInputElement>(null);

  const handleAdd = (vals: string[]) => {
    const row = [(rows.length + 1).toString(), ...vals.slice(1)];
    setRows(p => [...p, row]);
    setAdding(false);
    toast("تم إضافة السجل بنجاح");
  };

  const handleDelete = (i: number) => {
    setRows(p => p.filter((_, j) => j !== i).map((r, j) => [(j + 1).toString(), ...r.slice(1)]));
    toast("تم حذف السجل", "info");
  };

  return (
    <>
      <div className="overflow-x-auto border rounded text-xs" style={{ borderColor: C.border }}>
        <table className="w-full" dir="rtl">
          <thead>
            <tr style={{ background: C.tableHead, color: "#fff" }}>
              {cols.map(c => (
                <th key={c} className="px-2 py-1 text-center border-l" style={{ borderColor: "rgba(255,255,255,0.2)" }}>{c}</th>
              ))}
              <th className="w-5" />
            </tr>
          </thead>
          <tbody>
            {rows.length === 0
              ? <tr><td colSpan={cols.length + 1} className="text-center py-3" style={{ color: C.btnGray }}>لا توجد بيانات</td></tr>
              : rows.map((r, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? C.tableRow : C.tableAlt }}>
                  {r.map((c, j) => (
                    <td key={j} className="px-2 py-0.5 text-center border-l" style={{ borderColor: C.border }}>{c}</td>
                  ))}
                  <td className="text-center px-1">
                    <button onClick={() => handleDelete(i)} className="hover:text-red-700" style={{ color: C.btnRed }}><X size={12} /></button>
                  </td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>

      <div className="flex gap-1 mt-1 flex-wrap">
        <Btn label="إضافة" icon={Plus} small onClick={() => setAdding(true)} />
        {showPhoto && (
          <>
            <input type="file" accept="image/*,.pdf" className="hidden" ref={photoRef}
              onChange={() => toast("تم رفع صورة الكتاب بنجاح")} />
            <Btn label="صورة كتاب" icon={Camera} color={C.btnBlue} small
              onClick={() => photoRef.current?.click()} />
          </>
        )}
      </div>

      {adding && <AddRowDialog cols={cols} onSave={handleAdd} onCancel={() => setAdding(false)} />}
    </>
  );
}

// ─── Photo box ────────────────────────────────────────────────────────────────
function PhotoBox({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const [src, setSrc] = useState<string | null>(null);
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div className="flex flex-col items-center gap-1" style={{ width: 128 }}>
      <div className="border-2 rounded flex items-center justify-center overflow-hidden"
        style={{ width: 108, height: 128, borderColor: C.border, background: "#e0e0d4" }}>
        {src
          ? <img src={src} alt="الصورة الشخصية" className="w-full h-full object-cover" />
          : <div className="flex flex-col items-center gap-1" style={{ color: "#999" }}>
              <Camera size={30} /><span className="text-xs text-center">الصورة الشخصية</span>
            </div>
        }
      </div>
      <input type="file" accept="image/*" className="hidden" ref={ref}
        onChange={e => { const f = e.target.files?.[0]; if (f) { setSrc(URL.createObjectURL(f)); toast("تم اختيار الصورة"); } }} />
      <Btn label="اختيار صورة" icon={Upload} small onClick={() => ref.current?.click()} />
      <Btn label="حذف الصورة"  icon={Trash2} color={C.btnRed} small
        onClick={() => { setSrc(null); toast("تم حذف الصورة", "info"); }} />
    </div>
  );
}

// ─── Document upload row ──────────────────────────────────────────────────────
function DocRow({ label, toast }: { label: string; toast: (m: string, t?: ToastItem["type"]) => void }) {
  const [name, setName] = useState<string | null>(null);
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div className="flex items-center gap-3 py-2 border-b" dir="rtl" style={{ borderColor: C.border }}>
      <span className="text-xs font-semibold shrink-0" style={{ minWidth: 160 }}>{label}</span>
      <input type="file" accept="image/*,.pdf" className="hidden" ref={ref}
        onChange={e => { const f = e.target.files?.[0]; if (f) { setName(f.name); toast(`تم رفع: ${f.name}`); } }} />
      {name
        ? <span className="text-xs flex items-center gap-1" style={{ color: C.btnGreen }}><CheckCircle size={12} />{name}</span>
        : <span className="text-xs" style={{ color: "#999" }}>لم يتم الرفع</span>
      }
      <button onClick={() => ref.current?.click()}
        className="mr-auto text-xs px-2 py-0.5 rounded font-semibold text-white hover:opacity-80"
        style={{ background: C.btnBlue }}>إضافة صورة</button>
      {name && (
        <button onClick={() => { setName(null); toast("تم حذف الملف", "info"); }}
          className="hover:text-red-700" style={{ color: C.btnRed }}><X size={13} /></button>
      )}
    </div>
  );
}

// ─── TAB: المعلومات الشخصية ───────────────────────────────────────────────────
function TabPersonal({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const [d, setD] = useState({
    raqm: "123456", ratba: "نقيب", sinf: "ضابط",
    ism: "محمد احمد عبد الكريم العزاوي",
    badra: "أكاديمية الشرطة", wadha: "مستمر",
    wathiqa: "M-2023-987654", bitaqa: "1978-12-34-5678", jawaz: "QR-2023-876543",
    tahsil: "بكالوريوس", ikhtisas: "هندسة مدنية",
    tawalod: "1987-05-15", umm: "فاطمة علي",
    zawaj: "متزوج", zawja: "سارة محمود", atfal: "2",
    khadama: "خدمة مستمرة", jins: "ذكر", qawm: "عربي", din: "مسلم", mulahazat: "",
  });
  const s = (k: keyof typeof d) => (v: string) => setD(p => ({ ...p, [k]: v }));

  return (
    <div className="flex gap-3" dir="rtl">
      <div className="flex flex-col gap-2 shrink-0">
        <PhotoBox toast={toast} />
        <label className="text-xs font-semibold mt-1">ملاحظات</label>
        <textarea rows={5} className="border rounded px-2 py-1 text-xs resize-none"
          style={{ borderColor: C.border, width: 126, background: C.inputBg }}
          value={d.mulahazat} onChange={e => s("mulahazat")(e.target.value)} />
      </div>
      <div className="flex-1 min-w-0 grid grid-cols-2 gap-x-4">
        <div>
          <Field label="الرقم الإحصائي"         value={d.raqm}     onChange={s("raqm")} />
          <Field label="الرتبة"                  value={d.ratba}    onChange={s("ratba")} />
          <Field label="الصنف"                   value={d.sinf}     onChange={s("sinf")} />
          <Field label="الاسم الرباعي واللقب"    value={d.ism}      onChange={s("ism")} />
          <Field label="البادرة التي تخرج منها"  value={d.badra}    onChange={s("badra")} />
          <Sel   label="الوضع"                   value={d.wadha}    onChange={s("wadha")}
            options={["مستمر","موقوف","متقاعد","مفقود","متوفى"]} />
          <Field label="رقم الوثيقة العسكرية"    value={d.wathiqa}  onChange={s("wathiqa")} />
          <Field label="رقم البطاقة الموحدة"     value={d.bitaqa}   onChange={s("bitaqa")} />
          <Field label="رقم الجواز"              value={d.jawaz}    onChange={s("jawaz")} />
          <Field label="التحصيل الدراسي"         value={d.tahsil}   onChange={s("tahsil")} />
          <Field label="الاختصاص"                value={d.ikhtisas} onChange={s("ikhtisas")} />
        </div>
        <div>
          <Field label="التولد"           value={d.tawalod} onChange={s("tawalod")} type="date" />
          <Field label="اسم الأم"         value={d.umm}     onChange={s("umm")} />
          <Sel   label="الحالة الزوجية"   value={d.zawaj}   onChange={s("zawaj")}
            options={["أعزب","متزوج","مطلق","أرمل"]} />
          <Field label="اسم الزوجة"       value={d.zawja}   onChange={s("zawja")} />
          <Field label="عدد الأطفال"      value={d.atfal}   onChange={s("atfal")} />
          <Sel   label="الوضع الخدمي"     value={d.khadama} onChange={s("khadama")}
            options={["خدمة مستمرة","إجازة","موقوف","معار"]} />
          <Sel   label="الجنس"            value={d.jins}    onChange={s("jins")}   options={["ذكر","أنثى"]} />
          <Field label="القومية"           value={d.qawm}    onChange={s("qawm")} />
          <Sel   label="الديانة"          value={d.din}     onChange={s("din")}
            options={["مسلم","مسيحي","أيزيدي","صابئي"]} />
        </div>
      </div>
    </div>
  );
}

// ─── TAB: المعلومات العسكرية ──────────────────────────────────────────────────
function TabMilitary({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const [iqubat,    setIqubat]    = useState([["1","IQ-2020-001","2020/03/10"],["2","IQ-2021-045","2021/07/22"]]);
  const [dawarat,   setDawarat]   = useState([["1","دورة قيادة متقدمة","2019/05/01","بغداد"]]);
  const [tashkilat, setTashkilat] = useState([["1","شكر-2022-003","2022/11/15"]]);
  const [majalis,   setMajalis]   = useState<string[][]>([]);
  const [ijazat,    setIjazat]    = useState([["1","IJ-2023-012","2023/02/10"]]);
  const [amr, setAmr] = useState({ num: "", date: "" });
  const amrRef = useRef<HTMLInputElement>(null);

  return (
    <div className="space-y-4" dir="rtl">
      <div className="grid grid-cols-3 gap-3">
        <div>
          <h4 className="text-xs font-bold mb-1 px-2 py-0.5 text-white rounded" style={{ background: C.tableHead }}>العقوبات</h4>
          <ETable cols={["ت","رقم العقوبة","تاريخها"]} rows={iqubat} setRows={setIqubat} showPhoto toast={toast} />
        </div>
        <div>
          <h4 className="text-xs font-bold mb-1 px-2 py-0.5 text-white rounded" style={{ background: C.tableHead }}>الدورات</h4>
          <ETable cols={["ت","اسم الدورة","تاريخها","مكانها"]} rows={dawarat} setRows={setDawarat} showPhoto toast={toast} />
        </div>
        <div>
          <h4 className="text-xs font-bold mb-1 px-2 py-0.5 text-white rounded" style={{ background: C.tableHead }}>التشكلات</h4>
          <ETable cols={["ت","رقم الشكر","تاريخه"]} rows={tashkilat} setRows={setTashkilat} showPhoto toast={toast} />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div>
          <h4 className="text-xs font-bold mb-1 px-2 py-0.5 text-white rounded" style={{ background: C.btnBlue }}>أمر الفرد والإضاحي</h4>
          <Field label="أمر الفرد" value={amr.num}  onChange={v => setAmr(p => ({ ...p, num: v }))} />
          <Field label="تاريخ"     value={amr.date} onChange={v => setAmr(p => ({ ...p, date: v }))} type="date" />
          <input type="file" accept="image/*,.pdf" className="hidden" ref={amrRef}
            onChange={() => toast("تم رفع صورة أمر الفرد")} />
          <Btn label="صورة كتاب" icon={Camera} color={C.btnBlue} small onClick={() => amrRef.current?.click()} />
        </div>
        <div>
          <h4 className="text-xs font-bold mb-1 px-2 py-0.5 text-white rounded" style={{ background: C.btnBlue }}>المجالس التحقيقية</h4>
          <ETable cols={["ت","رقم المجلس","تاريخ","السبب"]} rows={majalis} setRows={setMajalis} showPhoto toast={toast} />
        </div>
        <div>
          <h4 className="text-xs font-bold mb-1 px-2 py-0.5 text-white rounded" style={{ background: C.btnBlue }}>الإجازات المرضية</h4>
          <ETable cols={["ت","رقم الإجازة","تاريخها"]} rows={ijazat} setRows={setIjazat} showPhoto toast={toast} />
        </div>
      </div>
    </div>
  );
}

// ─── TAB: العناوين ────────────────────────────────────────────────────────────
function TabAddresses() {
  const [d, setD] = useState({
    wilada: "بغداد", sakan: "بغداد - الكرخ", taWilada: "1987-05-15",
    amal: "وزارة الداخلية", dar: "45", bSakan: "",
    zuqaq: "12", mahala: "محلة العدل", tBSakan: "",
    ikhbar: "بغداد", mukhtar: "احمد سليم",
    nuqta: "حي العدل", hatif: "07801234567", badil: "07901234567",
  });
  const s = (k: keyof typeof d) => (v: string) => setD(p => ({ ...p, [k]: v }));
  return (
    <div className="grid grid-cols-2 gap-x-6" dir="rtl">
      <div>
        <Field label="محل الولادة"         value={d.wilada}   onChange={s("wilada")} />
        <Field label="محل السكن"           value={d.sakan}    onChange={s("sakan")} />
        <Field label="تاريخ الولادة"       value={d.taWilada} onChange={s("taWilada")} type="date" />
        <Field label="مكان العمل"          value={d.amal}     onChange={s("amal")} />
        <Field label="رقم الدار"           value={d.dar}      onChange={s("dar")} />
        <Field label="رقم البطاقة السكنية" value={d.bSakan}   onChange={s("bSakan")} />
        <Field label="الزقاق"              value={d.zuqaq}    onChange={s("zuqaq")} />
      </div>
      <div>
        <Field label="المحلة"              value={d.mahala}   onChange={s("mahala")} />
        <Field label="تاريخ بطاقة السكن"   value={d.tBSakan}  onChange={s("tBSakan")} type="date" />
        <Field label="محل الإخبار"         value={d.ikhbar}   onChange={s("ikhbar")} />
        <Field label="اسم المختار"         value={d.mukhtar}  onChange={s("mukhtar")} />
        <Field label="اقرب نقطة داله"      value={d.nuqta}    onChange={s("nuqta")} />
        <Field label="رقم هاتف"            value={d.hatif}    onChange={s("hatif")} />
        <Field label="الهاتف البديل"       value={d.badil}    onChange={s("badil")} />
      </div>
    </div>
  );
}

// ─── TAB: العائلة ─────────────────────────────────────────────────────────────
function TabFamily({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const items = ["مستمسكات الزوجة","مستمسكات الأطفال","عقد الزواج","مستمسكات الأبوين","جواز السفر","بطاقة السكن","بطاقة التموينية"];
  return (
    <div dir="rtl">
      <h4 className="text-xs font-bold mb-3 px-2 py-1 text-white rounded inline-block" style={{ background: C.tableHead }}>مستمسكات العائلة</h4>
      {items.map(l => <DocRow key={l} label={l} toast={toast} />)}
    </div>
  );
}

// ─── TAB: الاستحقاقات ─────────────────────────────────────────────────────────
function TabEntitlements({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const [tayin,  setTayin]  = useState({ amr: "", tarikh: "" });
  const [tarqia, setTarqia] = useState({ amr: "", tarikh: "", qadim: "" });
  const [alawa,  setAlawa]  = useState({ amr: "", tarikh: "", qadim: "" });
  const r1 = useRef<HTMLInputElement>(null);
  const r2 = useRef<HTMLInputElement>(null);
  const r3 = useRef<HTMLInputElement>(null);

  return (
    <div dir="rtl" className="space-y-4">
      {/* التعيين */}
      <div className="border rounded p-3" style={{ borderColor: C.border, background: C.panelBg }}>
        <h4 className="text-xs font-bold mb-2 px-2 py-0.5 text-white rounded inline-block" style={{ background: C.tableHead }}>التعيين</h4>
        <input type="file" accept="image/*,.pdf" className="hidden" ref={r1} onChange={() => toast("تم رفع صورة أمر التعيين")} />
        <div className="grid grid-cols-3 gap-3 items-end">
          <Field label="امر التعيين"   value={tayin.amr}    onChange={v => setTayin(p=>({...p,amr:v}))} />
          <Field label="تاريخ التعيين" value={tayin.tarikh} onChange={v => setTayin(p=>({...p,tarikh:v}))} type="date" />
          <div className="flex gap-1 pb-2">
            <Btn label="صورة"  icon={Camera} color={C.btnBlue} small onClick={() => r1.current?.click()} />
            <Btn label="اضافة" icon={Plus}                     small onClick={() => toast("تم حفظ بيانات التعيين")} />
          </div>
        </div>
      </div>
      {/* الترقية */}
      <div className="border rounded p-3" style={{ borderColor: C.border, background: C.panelBg }}>
        <h4 className="text-xs font-bold mb-2 px-2 py-0.5 text-white rounded inline-block" style={{ background: C.tableHead }}>الترقية</h4>
        <input type="file" accept="image/*,.pdf" className="hidden" ref={r2} onChange={() => toast("تم رفع صورة أمر الترقية")} />
        <div className="grid grid-cols-3 gap-3 items-end">
          <Field label="امر الترقية"   value={tarqia.amr}    onChange={v => setTarqia(p=>({...p,amr:v}))} />
          <Field label="تاريخ الترقية" value={tarqia.tarikh} onChange={v => setTarqia(p=>({...p,tarikh:v}))} type="date" />
          <div className="flex gap-1 pb-2">
            <Btn label="صورة"  icon={Camera} color={C.btnBlue} small onClick={() => r2.current?.click()} />
            <Btn label="اضافة" icon={Plus}                     small onClick={() => toast("تم حفظ بيانات الترقية")} />
          </div>
        </div>
        <Field label="تاريخ الترقية القادمة" value={tarqia.qadim} onChange={v => setTarqia(p=>({...p,qadim:v}))} type="date" />
      </div>
      {/* العلاوة */}
      <div className="border rounded p-3" style={{ borderColor: C.border, background: C.panelBg }}>
        <h4 className="text-xs font-bold mb-2 px-2 py-0.5 text-white rounded inline-block" style={{ background: C.tableHead }}>العلاوة</h4>
        <input type="file" accept="image/*,.pdf" className="hidden" ref={r3} onChange={() => toast("تم رفع صورة أمر العلاوة")} />
        <div className="grid grid-cols-3 gap-3 items-end">
          <Field label="امر العلاوة"   value={alawa.amr}    onChange={v => setAlawa(p=>({...p,amr:v}))} />
          <Field label="تاريخ العلاوة" value={alawa.tarikh} onChange={v => setAlawa(p=>({...p,tarikh:v}))} type="date" />
          <div className="flex gap-1 pb-2">
            <Btn label="صورة"  icon={Camera} color={C.btnBlue} small onClick={() => r3.current?.click()} />
            <Btn label="اضافة" icon={Plus}                     small onClick={() => toast("تم حفظ بيانات العلاوة")} />
          </div>
        </div>
        <Field label="تاريخ العلاوة القادمة" value={alawa.qadim} onChange={v => setAlawa(p=>({...p,qadim:v}))} type="date" />
      </div>
    </div>
  );
}

// ─── TAB: المستمسكات ──────────────────────────────────────────────────────────
function TabDocuments({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const items = ["صور الأحوال المدنية","الهوية الوزارية","جواز السفر","امر التعيين","امر الترقية","امر العلاوة","وثيقة دراسية","بطاقة السكن","بطاقة التموينية"];
  return (
    <div dir="rtl">
      <h4 className="text-xs font-bold mb-3 px-2 py-1 text-white rounded inline-block" style={{ background: C.tableHead }}>المستمسكات الرسمية</h4>
      {items.map(l => <DocRow key={l} label={l} toast={toast} />)}
    </div>
  );
}

// ─── TAB: ملاحظات ─────────────────────────────────────────────────────────────
function TabNotes({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const initial = "منتسب متميز ومنضبط، حصل على شهادة تقدير عام 2022.";
  const [note, setNote] = useState(initial);
  const [saved, setSaved] = useState(initial);
  return (
    <div dir="rtl" className="flex flex-col gap-3 h-full">
      <h4 className="text-xs font-bold px-2 py-1 text-white rounded inline-block" style={{ background: C.tableHead }}>ملاحظات المنتسب</h4>
      <textarea className="flex-1 border rounded p-3 text-sm resize-none"
        style={{ borderColor: C.border, background: C.inputBg, minHeight: 180, direction: "rtl" }}
        placeholder="أدخل الملاحظات هنا..." value={note} onChange={e => setNote(e.target.value)} />
      <div className="flex gap-2">
        <Btn label="حفظ الملاحظات" icon={Save}
          onClick={() => { setSaved(note); toast("تم حفظ الملاحظات بنجاح"); }} />
        <Btn label="تراجع" icon={RefreshCw} color={C.btnGray}
          onClick={() => { setNote(saved); toast("تم استعادة الملاحظات السابقة", "info"); }} />
      </div>
    </div>
  );
}

// ─── Search view ──────────────────────────────────────────────────────────────
function SearchView({ onSelect }: { onSelect: (idx: number) => void }) {
  const [q, setQ] = useState("");
  const [field, setField] = useState("الاسم الرباعي");
  const results = q.trim() ? PERSONNEL.filter(p => p.name.includes(q) || p.rank.includes(q)) : [];
  return (
    <div className="p-4 max-w-xl" dir="rtl">
      <h2 className="text-sm font-bold mb-3" style={{ color: C.tableHead }}>البحث المتقدم</h2>
      <div className="flex gap-2 mb-3">
        <select value={field} onChange={e => setField(e.target.value)}
          className="border rounded px-2 py-1 text-xs" style={{ borderColor: C.border }}>
          <option>الاسم الرباعي</option><option>الرتبة</option><option>الرقم الإحصائي</option>
        </select>
        <input value={q} onChange={e => setQ(e.target.value)}
          placeholder="أدخل نص البحث..."
          className="flex-1 border rounded px-3 py-1 text-xs" style={{ borderColor: C.border, direction: "rtl" }} />
      </div>
      {results.length > 0 && (
        <div className="border rounded overflow-hidden text-xs" style={{ borderColor: C.border }}>
          {results.map(p => {
            const idx = PERSONNEL.findIndex(x => x.id === p.id);
            return (
              <button key={p.id} onClick={() => onSelect(idx)}
                className="w-full text-right flex items-center gap-3 px-3 py-2 border-b transition-colors hover:bg-blue-50"
                style={{ borderColor: C.border }}>
                <span className="font-mono shrink-0" style={{ color: C.btnGray }}>{p.id}</span>
                <div className="flex-1"><div className="font-semibold">{p.name}</div><div style={{ color: C.btnGray }}>{p.rank}</div></div>
                <ChevronLeft size={13} style={{ color: C.btnGray }} />
              </button>
            );
          })}
        </div>
      )}
      {q.trim() && results.length === 0 && <p className="text-xs" style={{ color: C.btnGray }}>لا توجد نتائج مطابقة</p>}
    </div>
  );
}

// ─── Stats view ───────────────────────────────────────────────────────────────
function StatsView() {
  const cards = [
    { label: "إجمالي المنتسبين", val: "10", bg: C.tableHead },
    { label: "الضباط",           val: "4",  bg: C.btnBlue },
    { label: "الأفراد",          val: "6",  bg: C.btnGray },
    { label: "خدمة مستمرة",     val: "9",  bg: C.btnGreen },
    { label: "في إجازة",         val: "1",  bg: C.navActive },
    { label: "موقوفون",           val: "0",  bg: C.btnRed },
  ];
  return (
    <div className="p-6" dir="rtl">
      <h2 className="text-sm font-bold mb-4" style={{ color: C.tableHead }}>إحصائيات المنتسبين</h2>
      <div className="grid grid-cols-3 gap-4">
        {cards.map(c => (
          <div key={c.label} className="rounded-lg p-5 text-center text-white shadow-md" style={{ background: c.bg }}>
            <div className="text-4xl font-bold">{c.val}</div>
            <div className="text-xs mt-1 opacity-90">{c.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Settings view ───────────────────────────────────────────────────────────
function SettingsView({ toast }: { toast: (m: string, t?: ToastItem["type"]) => void }) {
  const [pass, setPass] = useState({ old: "", nw: "", confirm: "" });
  const [backup, setBackup] = useState("يومي");
  const [lang, setLang] = useState("العربية");
  const [theme, setTheme] = useState("الأخضر العسكري");

  return (
    <div className="p-4 max-w-lg" dir="rtl">
      <h2 className="text-sm font-bold mb-4" style={{ color: C.tableHead }}>الإعدادات</h2>

      {/* تغيير كلمة المرور */}
      <div className="border rounded p-3 mb-4" style={{ borderColor: C.border, background: C.panelBg }}>
        <h4 className="text-xs font-bold mb-3 px-2 py-0.5 text-white rounded inline-block" style={{ background: C.tableHead }}>تغيير كلمة المرور</h4>
        <Field label="كلمة المرور الحالية" value={pass.old}     onChange={v => setPass(p=>({...p,old:v}))}     type="password" />
        <Field label="كلمة المرور الجديدة" value={pass.nw}      onChange={v => setPass(p=>({...p,nw:v}))}      type="password" />
        <Field label="تأكيد كلمة المرور"   value={pass.confirm} onChange={v => setPass(p=>({...p,confirm:v}))} type="password" />
        <Btn label="حفظ التغييرات" icon={Save}
          onClick={() => {
            if (!pass.old || !pass.nw) { toast("يرجى ملء جميع الحقول", "err"); return; }
            if (pass.nw !== pass.confirm) { toast("كلمتا المرور غير متطابقتان", "err"); return; }
            toast("تم تغيير كلمة المرور بنجاح");
            setPass({ old: "", nw: "", confirm: "" });
          }} />
      </div>

      {/* إعدادات النظام */}
      <div className="border rounded p-3 mb-4" style={{ borderColor: C.border, background: C.panelBg }}>
        <h4 className="text-xs font-bold mb-3 px-2 py-0.5 text-white rounded inline-block" style={{ background: C.tableHead }}>إعدادات النظام</h4>
        <Sel label="اللغة"           value={lang}   onChange={setLang}   options={["العربية","English"]} />
        <Sel label="السمة البصرية"    value={theme}  onChange={setTheme}  options={["الأخضر العسكري","الداكن","الفاتح"]} />
        <Sel label="النسخ الاحتياطي" value={backup} onChange={setBackup} options={["يومي","أسبوعي","شهري","يدوي"]} />
        <div className="mt-2 flex gap-2">
          <Btn label="حفظ الإعدادات" icon={Save}     onClick={() => toast("تم حفظ الإعدادات بنجاح")} />
          <Btn label="إعادة ضبط"     icon={RefreshCw} color={C.btnGray} onClick={() => { setLang("العربية"); setTheme("الأخضر العسكري"); setBackup("يومي"); toast("تم إعادة الضبط إلى الافتراضي", "info"); }} />
        </div>
      </div>

      {/* معلومات النظام */}
      <div className="border rounded p-3" style={{ borderColor: C.border, background: C.panelBg }}>
        <h4 className="text-xs font-bold mb-2 px-2 py-0.5 text-white rounded inline-block" style={{ background: C.tableHead }}>معلومات النظام</h4>
        <div className="text-xs space-y-1" style={{ color: "#444" }}>
          <div className="flex gap-2"><span className="font-semibold" style={{ minWidth: 130 }}>اسم النظام:</span><span>نظام إدارة المنتسبين</span></div>
          <div className="flex gap-2"><span className="font-semibold" style={{ minWidth: 130 }}>الإصدار:</span><span>1.0.0</span></div>
          <div className="flex gap-2"><span className="font-semibold" style={{ minWidth: 130 }}>قاعدة البيانات:</span><span>Employees.accdb</span></div>
          <div className="flex gap-2"><span className="font-semibold" style={{ minWidth: 130 }}>المستخدم الحالي:</span><span>Admin</span></div>
        </div>
      </div>
    </div>
  );
}

// ─── Personnel data ───────────────────────────────────────────────────────────
const PERSONNEL = [
  { id:1,  name:"محمد احمد عبد الكريم العزاوي", rank:"نقيب" },
  { id:2,  name:"علي حسين حميد",                rank:"ملازم" },
  { id:3,  name:"احمد صباح حسن",                rank:"رائد" },
  { id:4,  name:"مصطفى فاضل محمد",              rank:"عقيد" },
  { id:5,  name:"سجاد كريم عبد",               rank:"ملازم أول" },
  { id:6,  name:"حيدر عبد الزهرة كاظم",        rank:"رقيب" },
  { id:7,  name:"محمد جاسم محمد",               rank:"نقيب" },
  { id:8,  name:"كرار حيدر سلمان",             rank:"مقدم" },
  { id:9,  name:"يوسف رائد عبد الله",          rank:"ملازم" },
  { id:10, name:"احمد مهدي صالح",              rank:"عريف" },
];

// ─── Main App ────────────────────────────────────────────────────────────────
export default function App() {
  const [now, setNow] = useState(new Date());
  const [nav, setNav] = useState("المنتسبين");
  const [tab, setTab] = useState("المعلومات الشخصية");
  const [idx, setIdx] = useState(0);
  const [q, setQ] = useState("");
  const [confirm, setConfirm] = useState<{ msg: string; cb: () => void } | null>(null);
  const { list: toasts, add: toast, remove: removeToast } = useToast();

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const filtered = PERSONNEL.filter(p => !q || p.name.includes(q) || p.rank.includes(q));

  // يحدد الزر النشط بشكل صحيح حتى عند التوجيه عبر التبويبات
  const isNavActive = (nav: string, tab: string, label: string) => {
    if (label === "الاستحقاقات") return nav === "المنتسبين" && tab === "الاستحقاقات";
    if (label === "العناوين")    return nav === "المنتسبين" && tab === "العناوين";
    if (label === "المستمسكات") return nav === "المنتسبين" && tab === "المستمسكات";
    if (label === "الملاحظات")  return nav === "المنتسبين" && tab === "ملاحظات";
    if (label === "المنتسبين")  return nav === "المنتسبين" && !["الاستحقاقات","العناوين","المستمسكات","ملاحظات"].includes(tab);
    return nav === label;
  };

  // ضغط زر التنقل العلوي يوجّه للمحتوى الصحيح
  const handleNav = (label: string) => {
    if (label === "الاستحقاقات") { setNav("المنتسبين"); setTab("الاستحقاقات"); }
    else if (label === "العناوين")  { setNav("المنتسبين"); setTab("العناوين"); }
    else if (label === "المستمسكات") { setNav("المنتسبين"); setTab("المستمسكات"); }
    else if (label === "الملاحظات")  { setNav("المنتسبين"); setTab("ملاحظات"); }
    else { setNav(label); }
  };

  const showTabs = nav !== "البحث" && nav !== "إحصائيات" && nav !== "الإعدادات";
  const recordTabs = ["المعلومات الشخصية","المعلومات العسكرية","العناوين","العائلة","الاستحقاقات","المستمسكات","ملاحظات"];

  const navItems = [
    { label:"الرئيسية",    icon: Home },
    { label:"المنتسبين",   icon: Users },
    { label:"البحث",       icon: Search },
    { label:"الاستحقاقات", icon: FileText },
    { label:"العناوين",    icon: MapPin },
    { label:"المستمسكات", icon: Archive },
    { label:"الإعدادات",  icon: Settings },
    { label:"الملاحظات",  icon: Bell },
  ];

  const sideItems: { label: string; icon: any; action: () => void }[] = [
    { label:"القائمة الرئيسية",          icon: Home,      action: () => setNav("الرئيسية") },
    { label:"إضافة منتسب جديد",          icon: UserPlus,  action: () => toast("فتح نموذج إضافة منتسب جديد", "info") },
    { label:"تعديل / عرض منتسب",         icon: Edit,      action: () => { setNav("المنتسبين"); setTab("المعلومات الشخصية"); } },
    { label:"بحث متقدم",                 icon: Search,    action: () => setNav("البحث") },
    { label:"الاستحقاقات المالية",       icon: FileText,  action: () => { setNav("المنتسبين"); setTab("الاستحقاقات"); } },
    { label:"العائلة",                   icon: Users,     action: () => { setNav("المنتسبين"); setTab("العائلة"); } },
    { label:"العناوين",                  icon: MapPin,    action: () => { setNav("المنتسبين"); setTab("العناوين"); } },
    { label:"المستمسكات",                icon: Archive,   action: () => { setNav("المنتسبين"); setTab("المستمسكات"); } },
    { label:"التقارير والطباعة",         icon: Printer,   action: () => { toast("جاري تحضير التقرير...", "info"); setTimeout(() => window.print(), 400); } },
    { label:"إحصائيات",                 icon: BarChart2,  action: () => setNav("إحصائيات") },
    { label:"تسجيل الدخول والصلاحيات", icon: Lock,      action: () => toast("إدارة الصلاحيات — قيد التطوير", "info") },
    { label:"نسخ احتياطي",             icon: Database,   action: () => toast("تم إنشاء نسخة احتياطية بنجاح") },
  ];

  const content = () => {
    if (nav === "البحث")      return <SearchView onSelect={i => { setIdx(i); setNav("المنتسبين"); }} />;
    if (nav === "إحصائيات")   return <StatsView />;
    if (nav === "الإعدادات")  return <SettingsView toast={toast} />;
    switch (tab) {
      case "المعلومات الشخصية":  return <TabPersonal   toast={toast} />;
      case "المعلومات العسكرية": return <TabMilitary   toast={toast} />;
      case "العناوين":           return <TabAddresses />;
      case "العائلة":            return <TabFamily     toast={toast} />;
      case "الاستحقاقات":        return <TabEntitlements toast={toast} />;
      case "المستمسكات":         return <TabDocuments  toast={toast} />;
      case "ملاحظات":            return <TabNotes      toast={toast} />;
    }
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden"
      style={{ fontFamily: "'Noto Kufi Arabic', sans-serif", direction: "rtl" }}>

      <Toasts list={toasts} remove={removeToast} />
      {confirm && (
        <Confirm msg={confirm.msg}
          onYes={() => { confirm.cb(); setConfirm(null); }}
          onNo={() => setConfirm(null)} />
      )}

      {/* ── Header ── */}
      <div className="flex items-center px-3 py-1.5 shrink-0 gap-3"
        style={{ background: C.headerBg, color: C.headerText }}>
        <div className="flex items-center justify-center rounded-full border-2 shrink-0"
          style={{ width: 50, height: 50, borderColor: C.accent, background: "#4a2a10" }}>
          <Shield size={26} style={{ color: C.accent }} />
        </div>
        <div className="flex-1 text-center">
          <h1 className="font-bold" style={{ fontSize: 17, color: C.accent }}>
            نظام إدارة المنتسبين – وزارة الداخلية
          </h1>
          <p className="text-xs opacity-75">قاعدة بيانات الأفراد والموظفين</p>
        </div>
        <div className="text-xs shrink-0 flex flex-col items-start gap-0.5 opacity-90">
          <span>{now.toLocaleDateString("ar-IQ")}</span>
          <span>{now.toLocaleTimeString("ar-IQ")}</span>
          <span className="font-bold" style={{ color: C.navActive }}>User: Admin</span>
        </div>
      </div>

      {/* ── Top nav ── */}
      <div className="flex items-center shrink-0 overflow-x-auto" style={{ background: C.navBg }}>
        {navItems.map(({ label, icon: Icon }) => (
          <button key={label} onClick={() => handleNav(label)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold whitespace-nowrap border-l transition-colors"
            style={{
              color: isNavActive(nav, tab, label) ? C.navActive : "#d0c0a0",
              background: isNavActive(nav, tab, label) ? "rgba(200,168,74,0.15)" : "transparent",
              borderColor: "rgba(255,255,255,0.1)",
              borderBottom: isNavActive(nav, tab, label) ? `2px solid ${C.navActive}` : "2px solid transparent",
            }}>
            <Icon size={14} />{label}
          </button>
        ))}
      </div>

      {/* ── Body ── */}
      <div className="flex flex-1 overflow-hidden">

        {/* Sidebar */}
        <div className="flex flex-col shrink-0 overflow-y-auto" style={{ width: 158, background: C.sidebarBg }}>
          <div className="px-2 py-1.5 text-xs font-bold text-center border-b"
            style={{ color: C.accent, borderColor: "rgba(255,255,255,0.1)" }}>القائمة الرئيسية</div>
          {sideItems.map(({ label, icon: Icon, action }) => (
            <button key={label} onClick={action}
              className="flex items-center gap-2 px-2 py-1.5 text-xs text-right w-full border-b transition-colors"
              style={{ color: C.sidebarText, borderColor: "rgba(255,255,255,0.06)" }}
              onMouseEnter={e => (e.currentTarget.style.background = C.sidebarHover)}
              onMouseLeave={e => (e.currentTarget.style.background = "transparent")}>
              <Icon size={13} style={{ color: C.accent, flexShrink: 0 }} />
              <span className="leading-tight">{label}</span>
            </button>
          ))}
          <div className="mt-auto border-t" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
            <button
              onClick={() => setConfirm({ msg: "هل تريد الخروج من النظام؟", cb: () => toast("تم الخروج من النظام", "info") })}
              className="flex items-center gap-2 px-2 py-2 text-xs w-full font-bold text-white hover:opacity-80"
              style={{ background: C.btnRed }}>
              <LogOut size={13} />خروج من النظام
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col overflow-hidden" style={{ background: C.contentBg }}>

          {/* Sub-tabs */}
          {showTabs && (
            <div className="flex items-center shrink-0 border-b overflow-x-auto"
              style={{ background: "#d8d8cc", borderColor: C.border }}>
              {recordTabs.map(t => (
                <button key={t} onClick={() => setTab(t)}
                  className="px-3 py-1.5 text-xs font-bold whitespace-nowrap border-l transition-colors"
                  style={{
                    background: tab === t ? C.tabActive : "transparent",
                    color:      tab === t ? "#fff" : C.tabText,
                    borderColor: C.border,
                  }}>{t}</button>
              ))}
            </div>
          )}

          {/* Tab body */}
          <div className="flex-1 overflow-y-auto p-3">{content()}</div>

          {/* Toolbar */}
          {showTabs && (
            <div className="shrink-0 flex items-center gap-1 px-3 py-1.5 border-t flex-wrap"
              style={{ background: "#d0d0c4", borderColor: C.border }}>
              {/* Navigation */}
              <div className="flex items-center gap-1 border-l pl-2 ml-1" style={{ borderColor: C.border }}>
                <button onClick={() => { if (idx > 0) { setIdx(p => p-1); toast(`السجل ${idx}`,"info"); } }}
                  disabled={idx === 0}
                  className="w-6 h-6 rounded flex items-center justify-center text-white disabled:opacity-40 hover:opacity-80"
                  style={{ background: C.btnGray }}><ChevronRight size={14} /></button>
                <button onClick={() => { if (idx < PERSONNEL.length-1) { setIdx(p => p+1); toast(`السجل ${idx+2}`,"info"); } }}
                  disabled={idx === PERSONNEL.length-1}
                  className="w-6 h-6 rounded flex items-center justify-center text-white disabled:opacity-40 hover:opacity-80"
                  style={{ background: C.btnGray }}><ChevronLeft size={14} /></button>
                <span className="text-xs px-1">{idx+1} من {PERSONNEL.length}</span>
              </div>
              <Btn label="حفظ"   icon={Save}      onClick={() => toast("تم حفظ بيانات المنتسب بنجاح")} />
              <Btn label="جديد"  icon={Plus}       color={C.btnBlue} onClick={() => toast("فتح نموذج إضافة منتسب جديد", "info")} />
              <Btn label="حذف"   icon={Trash2}     color={C.btnRed}
                onClick={() => setConfirm({ msg: `هل تريد حذف بيانات: ${PERSONNEL[idx].name}؟`, cb: () => toast("تم حذف السجل", "info") })} />
              <Btn label="طباعة" icon={Printer}    color={C.btnGray} onClick={() => { toast("جاري الطباعة...", "info"); setTimeout(() => window.print(), 300); }} />
              <Btn label="تراجع" icon={RefreshCw}  color={C.btnGray} onClick={() => toast("تم التراجع عن آخر تعديل", "info")} />
              <Btn label="إغلاق" icon={X}          color={C.btnGray} onClick={() => toast("تم إغلاق السجل الحالي", "info")} />
            </div>
          )}
        </div>

        {/* Right panel */}
        <div className="shrink-0 flex flex-col border-r overflow-hidden"
          style={{ width: 208, borderColor: C.border, background: C.panelBg }}>
          {/* Quick search */}
          <div className="p-2 border-b" style={{ borderColor: C.border, background: "#e8e8dc" }}>
            <div className="text-xs font-bold mb-1" style={{ color: C.sidebarBg }}>بحث سريع</div>
            <select className="w-full text-xs border rounded px-1 py-0.5 mb-1" style={{ borderColor: C.border }}>
              <option>الاسم الرباعي</option><option>الرقم الإحصائي</option><option>الرتبة</option>
            </select>
            <input value={q} onChange={e => setQ(e.target.value)}
              placeholder="نص البحث"
              className="w-full border rounded px-2 py-0.5 text-xs mb-1"
              style={{ borderColor: C.border, direction: "rtl" }} />
            <div className="flex gap-1">
              <Btn label="بحث" icon={Search} small
                onClick={() => toast(`بحث عن: "${q || "الكل"}"`, "info")} />
              <Btn label="مسح" icon={X} color={C.btnGray} small
                onClick={() => { setQ(""); toast("تم مسح حقل البحث", "info"); }} />
            </div>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto">
            <div className="text-xs font-bold px-2 py-1 text-white" style={{ background: C.tableHead }}>
              قائمة المنتسبين
            </div>
            {filtered.map(p => {
              const pi = PERSONNEL.findIndex(x => x.id === p.id);
              return (
                <button key={p.id}
                  onClick={() => { setIdx(pi); setNav("المنتسبين"); }}
                  className="w-full text-right px-2 py-1.5 text-xs border-b flex gap-2 items-center transition-colors"
                  style={{ borderColor: C.border, background: pi === idx ? C.listSelect : "transparent", color: "#1a1a1a" }}>
                  <span className="shrink-0 font-mono" style={{ color: C.btnGray, minWidth: 18 }}>{p.id}</span>
                  <div className="flex-1 min-w-0">
                    <div className="truncate font-semibold leading-tight">{p.name}</div>
                    <div className="text-gray-500">{p.rank}</div>
                  </div>
                </button>
              );
            })}
            <div className="text-xs text-center py-1 border-t" style={{ borderColor: C.border, color: C.btnGray }}>
              إجمالي العدد: {filtered.length}
            </div>
          </div>
        </div>

      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-0.5 shrink-0 text-xs"
        style={{ background: C.headerBg, color: C.headerText }}>
        <span>User: Admin</span>
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full inline-block" style={{ background: "#4ade80" }} />
          حالة الاتصال: متصل
        </span>
        <span>قاعدة البيانات: Employees.accdb</span>
      </div>

    </div>
  );
}
